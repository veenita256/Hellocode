package com.icici;

public interface Bank {
	void deposite(int amount);
	void withdraw(int amount);
	int getBalance();
}
